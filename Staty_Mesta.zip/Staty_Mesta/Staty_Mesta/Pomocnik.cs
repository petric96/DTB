﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Staty_Mesta
{
    class Polozka
    {
        public string Stat { get; }
        public string Mesto { get; }
        public bool Hlavni { get; }
        public int Obyvatele { get; }
        public int Rozloha { get; }
        public int Zrizeni { get; }
        public int Mena { get; }
        public string Hlava { get; }

        public Polozka(string stat, string mesto, bool hlavni, int obyvatele, int rozloha, int zrizeni, int mena, string hlava)
        {
            Stat = stat;
            Mesto = mesto;
            Hlavni = hlavni;
            Obyvatele = obyvatele;
            Rozloha = rozloha;
            Zrizeni = zrizeni;
            Mena = mena;
            Hlava = hlava;
        }
    }
}
