﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Staty_Mesta
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Polozka> polozky = new List<Polozka>();
        //připojení k databázi
        string databaze = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=H:\Dokumenty\databaze.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection pripojeni;
        private void Form1_Load(object sender, EventArgs e)
        {
            vypis();
        }

        void vypis()
        {
            //výpis z databáze do listboxu
            lb_databaze.Items.Clear();
            pripojeni = new SqlConnection(databaze);
            string text_prikaz = "SELECT * FROM Zaklad";
            SqlCommand prikaz = new SqlCommand(text_prikaz, pripojeni);
            pripojeni.Open();
            SqlDataReader zaznamy = prikaz.ExecuteReader();
            while (zaznamy.Read())
            {
                polozky.Add(new Polozka(zaznamy["stat"].ToString(), zaznamy["mesto"].ToString(), Convert.ToBoolean(zaznamy["hl_mesto"]), Convert.ToInt32(zaznamy["poc_obyv"]), Convert.ToInt32(zaznamy["rozloha"]), Convert.ToInt16(zaznamy["id_zrizeni"]), Convert.ToInt16(zaznamy["id_mena"]), zaznamy["hlava_statu"].ToString()));
                lb_databaze.Items.Add(polozky[polozky.Count - 1].Stat + " | " + polozky[polozky.Count - 1].Mesto);
            }
            pripojeni.Close();
        }

        private void bt_pridat_Click(object sender, EventArgs e)
        {
            //přidání záznamu
            polozky.Add(new Polozka(tb_stat.Text, tb_mesto.Text, Convert.ToBoolean(cb_hlavni.Checked), int.Parse(tb_obyvatele.Text), int.Parse(tb_rozloha.Text), cb_zrizeni.SelectedIndex + 1, cb_mena.SelectedIndex + 1, tb_hlava.Text));
            string vlozit = $"INSERT INTO Zaklad(stat, mesto, hl_mesto, poc_obyv, rozloha, id_zrizeni, id_mena, hlava_statu) VALUES ('{tb_stat.Text}', '{tb_mesto.Text}', '{Convert.ToInt16(cb_hlavni.Checked)}', '{int.Parse(tb_obyvatele.Text)}', '{int.Parse(tb_rozloha.Text)}', '{cb_zrizeni.SelectedIndex + 1}', '{cb_mena.SelectedIndex + 1}', '{tb_hlava.Text}')";
            pripojeni.Open();
            SqlCommand prikaz = new SqlCommand(vlozit, pripojeni);
            prikaz.ExecuteNonQuery();
            pripojeni.Close();
            vypis();
        }

        private void bt_editovat_Click(object sender, EventArgs e)
        {
            /*string edit = $"UPDATE Zaklad SET Name(stat, mesto, hl_mesto, poc_obyv, rozloha, id_zrizeni, id_mena, hlava_statu) VALUES ('{tb_stat.Text}', '{tb_mesto.Text}', '{Convert.ToInt16(cb_hlavni.Checked)}', '{int.Parse(tb_obyvatele.Text)}', '{int.Parse(tb_rozloha.Text)}', '{cb_zrizeni.SelectedIndex + 1}', '{cb_mena.SelectedIndex + 1}', '{tb_hlava.Text}')";
            pripojeni.Open();
            SqlCommand prikaz = new SqlCommand(edit, pripojeni);
            prikaz.ExecuteNonQuery();
            pripojeni.Close();
            vypis();*/
            int polozka= lb_databaze.SelectedIndex;
            polozky[polozka].Stat = tb_stat.Text;
            polozky[polozka].Mesto = tb_mesto.Text;
            polozky[polozka].Hlavni = Convert.ToBoolean(cb_hlavni.Checked);
            polozky[polozka].Obyvatele = Convert.ToInt32(tb_obyvatele.Text);
            polozky[polozka].Rozloha = Convert.ToInt32(tb_rozloha.Text);
            polozky[polozka].Zrizeni = Convert.ToInt16(cb_zrizeni.SelectedIndex);
            polozky[polozka].Mena = Convert.ToInt16(cb_mena.SelectedIndex);
            polozky[polozka].Hlava = tb_hlava.Text;
            string edit = $"UPDATE Zaklad SET stat='{tb_stat.Text}' WHERE id='{polozka + 1}'";
            pripojeni.Open();
            SqlCommand prikaz = new SqlCommand(edit, pripojeni);
            prikaz.ExecuteNonQuery();
            pripojeni.Close();
            vypis();
        }

        private void bt_smazat_Click(object sender, EventArgs e)
        {

        }

        private void zmena(object sender, EventArgs e)
        {
            //povolení tlačítka přidat
            if (tb_stat.Text.Length >= 3 && tb_mesto.Text.Length >= 3 && tb_obyvatele.Text.Length >= 1 && tb_rozloha.Text.Length >= 1 && cb_zrizeni.Text != "" && cb_mena.Text != "" && tb_hlava.Text.Length >= 3)
            {
                bt_pridat.Enabled = true;
                bt_editovat.Enabled = true;
            }
            else
            {
                bt_pridat.Enabled = false;
                bt_editovat.Enabled = false;
            }
        }

        private void lb_databaze_SelectedIndexChanged(object sender, EventArgs e)
        {
            tb_stat.Text = polozky[lb_databaze.SelectedIndex].Stat;
            tb_mesto.Text = polozky[lb_databaze.SelectedIndex].Mesto;
            if (polozky[lb_databaze.SelectedIndex].Hlavni == true)
                cb_hlavni.Checked = true;
            else
                cb_hlavni.Checked = false;
            tb_obyvatele.Text = polozky[lb_databaze.SelectedIndex].Obyvatele.ToString();
            tb_rozloha.Text = polozky[lb_databaze.SelectedIndex].Rozloha.ToString();
            cb_zrizeni.SelectedIndex = (polozky[lb_databaze.SelectedIndex].Zrizeni) - 1;
            cb_mena.SelectedIndex = (polozky[lb_databaze.SelectedIndex].Mena) - 1;
            tb_hlava.Text = polozky[lb_databaze.SelectedIndex].Hlava;
        }
    }
}
