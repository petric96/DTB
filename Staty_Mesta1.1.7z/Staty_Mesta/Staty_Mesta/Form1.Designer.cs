﻿namespace Staty_Mesta
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_databaze = new System.Windows.Forms.ListBox();
            this.lb_filtrace = new System.Windows.Forms.ListBox();
            this.tb_stat = new System.Windows.Forms.TextBox();
            this.tb_mesto = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_hlavni = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_obyvatele = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_rozloha = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_hlava = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cb_zrizeni = new System.Windows.Forms.ComboBox();
            this.cb_mena = new System.Windows.Forms.ComboBox();
            this.bt_pridat = new System.Windows.Forms.Button();
            this.bt_smazat = new System.Windows.Forms.Button();
            this.bt_editovat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_databaze
            // 
            this.lb_databaze.FormattingEnabled = true;
            this.lb_databaze.Location = new System.Drawing.Point(12, 12);
            this.lb_databaze.Name = "lb_databaze";
            this.lb_databaze.Size = new System.Drawing.Size(205, 277);
            this.lb_databaze.TabIndex = 0;
            this.lb_databaze.SelectedIndexChanged += new System.EventHandler(this.lb_databaze_SelectedIndexChanged);
            // 
            // lb_filtrace
            // 
            this.lb_filtrace.FormattingEnabled = true;
            this.lb_filtrace.Location = new System.Drawing.Point(822, 12);
            this.lb_filtrace.Name = "lb_filtrace";
            this.lb_filtrace.Size = new System.Drawing.Size(205, 277);
            this.lb_filtrace.TabIndex = 1;
            // 
            // tb_stat
            // 
            this.tb_stat.Location = new System.Drawing.Point(345, 12);
            this.tb_stat.Name = "tb_stat";
            this.tb_stat.Size = new System.Drawing.Size(199, 20);
            this.tb_stat.TabIndex = 2;
            this.tb_stat.Text = "test";
            this.tb_stat.TextChanged += new System.EventHandler(this.zmena);
            // 
            // tb_mesto
            // 
            this.tb_mesto.Location = new System.Drawing.Point(345, 38);
            this.tb_mesto.Name = "tb_mesto";
            this.tb_mesto.Size = new System.Drawing.Size(199, 20);
            this.tb_mesto.TabIndex = 3;
            this.tb_mesto.Text = "test";
            this.tb_mesto.TextChanged += new System.EventHandler(this.zmena);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(284, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Město:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(294, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Stát:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(254, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Hlavni město ?";
            // 
            // cb_hlavni
            // 
            this.cb_hlavni.AutoSize = true;
            this.cb_hlavni.Location = new System.Drawing.Point(345, 70);
            this.cb_hlavni.Name = "cb_hlavni";
            this.cb_hlavni.Size = new System.Drawing.Size(45, 17);
            this.cb_hlavni.TabIndex = 7;
            this.cb_hlavni.Text = "Ano";
            this.cb_hlavni.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(242, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Počet obyvatel:";
            // 
            // tb_obyvatele
            // 
            this.tb_obyvatele.Location = new System.Drawing.Point(345, 93);
            this.tb_obyvatele.Name = "tb_obyvatele";
            this.tb_obyvatele.Size = new System.Drawing.Size(199, 20);
            this.tb_obyvatele.TabIndex = 9;
            this.tb_obyvatele.Text = "123";
            this.tb_obyvatele.TextChanged += new System.EventHandler(this.zmena);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(274, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Rozloha:";
            // 
            // tb_rozloha
            // 
            this.tb_rozloha.Location = new System.Drawing.Point(345, 128);
            this.tb_rozloha.Name = "tb_rozloha";
            this.tb_rozloha.Size = new System.Drawing.Size(199, 20);
            this.tb_rozloha.TabIndex = 11;
            this.tb_rozloha.Text = "321";
            this.tb_rozloha.TextChanged += new System.EventHandler(this.zmena);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(223, 226);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Hlava státu:";
            // 
            // tb_hlava
            // 
            this.tb_hlava.Location = new System.Drawing.Point(291, 223);
            this.tb_hlava.Name = "tb_hlava";
            this.tb_hlava.Size = new System.Drawing.Size(253, 20);
            this.tb_hlava.TabIndex = 13;
            this.tb_hlava.Text = "Testiček";
            this.tb_hlava.TextChanged += new System.EventHandler(this.zmena);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(286, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Měna:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(247, 162);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Státní zřízení:";
            // 
            // cb_zrizeni
            // 
            this.cb_zrizeni.FormattingEnabled = true;
            this.cb_zrizeni.Items.AddRange(new object[] {
            "Konstituční monarchie",
            "Poloprezidentská republika",
            "Federativní parlamentní republika",
            "Konstituční monarchie",
            "Konfederativní republika",
            "Parlamentní republika",
            "Knížectví"});
            this.cb_zrizeni.Location = new System.Drawing.Point(345, 159);
            this.cb_zrizeni.Name = "cb_zrizeni";
            this.cb_zrizeni.Size = new System.Drawing.Size(199, 21);
            this.cb_zrizeni.TabIndex = 16;
            this.cb_zrizeni.SelectedIndexChanged += new System.EventHandler(this.zmena);
            // 
            // cb_mena
            // 
            this.cb_mena.FormattingEnabled = true;
            this.cb_mena.Items.AddRange(new object[] {
            "Švédská koruna",
            "Ukrajinská hřivna",
            "Euro",
            "Konvertibilné marky",
            "Zlotý"});
            this.cb_mena.Location = new System.Drawing.Point(345, 192);
            this.cb_mena.Name = "cb_mena";
            this.cb_mena.Size = new System.Drawing.Size(199, 21);
            this.cb_mena.TabIndex = 17;
            this.cb_mena.SelectedIndexChanged += new System.EventHandler(this.zmena);
            // 
            // bt_pridat
            // 
            this.bt_pridat.Enabled = false;
            this.bt_pridat.Location = new System.Drawing.Point(468, 251);
            this.bt_pridat.Name = "bt_pridat";
            this.bt_pridat.Size = new System.Drawing.Size(76, 38);
            this.bt_pridat.TabIndex = 18;
            this.bt_pridat.Text = "Přidat";
            this.bt_pridat.UseVisualStyleBackColor = true;
            this.bt_pridat.Click += new System.EventHandler(this.bt_pridat_Click);
            // 
            // bt_smazat
            // 
            this.bt_smazat.Enabled = false;
            this.bt_smazat.Location = new System.Drawing.Point(291, 251);
            this.bt_smazat.Name = "bt_smazat";
            this.bt_smazat.Size = new System.Drawing.Size(76, 38);
            this.bt_smazat.TabIndex = 19;
            this.bt_smazat.Text = "Smazat";
            this.bt_smazat.UseVisualStyleBackColor = true;
            this.bt_smazat.Click += new System.EventHandler(this.bt_smazat_Click);
            // 
            // bt_editovat
            // 
            this.bt_editovat.Enabled = false;
            this.bt_editovat.Location = new System.Drawing.Point(373, 251);
            this.bt_editovat.Name = "bt_editovat";
            this.bt_editovat.Size = new System.Drawing.Size(89, 38);
            this.bt_editovat.TabIndex = 20;
            this.bt_editovat.Text = "Editovat";
            this.bt_editovat.UseVisualStyleBackColor = true;
            this.bt_editovat.Click += new System.EventHandler(this.bt_editovat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 316);
            this.Controls.Add(this.bt_editovat);
            this.Controls.Add(this.bt_smazat);
            this.Controls.Add(this.bt_pridat);
            this.Controls.Add(this.cb_mena);
            this.Controls.Add(this.cb_zrizeni);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tb_hlava);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tb_rozloha);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_obyvatele);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cb_hlavni);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_mesto);
            this.Controls.Add(this.tb_stat);
            this.Controls.Add(this.lb_filtrace);
            this.Controls.Add(this.lb_databaze);
            this.Name = "Form1";
            this.Text = "Státy";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lb_databaze;
        private System.Windows.Forms.ListBox lb_filtrace;
        private System.Windows.Forms.TextBox tb_stat;
        private System.Windows.Forms.TextBox tb_mesto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cb_hlavni;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_obyvatele;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_rozloha;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_hlava;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cb_zrizeni;
        private System.Windows.Forms.ComboBox cb_mena;
        private System.Windows.Forms.Button bt_pridat;
        private System.Windows.Forms.Button bt_smazat;
        private System.Windows.Forms.Button bt_editovat;
    }
}

