﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Staty_Mesta
{
    class Polozka
    {
        public string Stat { get; set; }
        public string Mesto { get; set; }
        public bool Hlavni { get; set; }
        public int Obyvatele { get; set; }
        public int Rozloha { get; set; }
        public int Zrizeni { get; set; }
        public int Mena { get; set; }
        public string Hlava { get; set; }

        public Polozka(string stat, string mesto, bool hlavni, int obyvatele, int rozloha, int zrizeni, int mena, string hlava)
        {
            Stat = stat;
            Mesto = mesto;
            Hlavni = hlavni;
            Obyvatele = obyvatele;
            Rozloha = rozloha;
            Zrizeni = zrizeni;
            Mena = mena;
            Hlava = hlava;
        }
    }
}
