﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Staty_Mesta
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //list pro pozdější práci ve formu
        List<Polozka> polozky = new List<Polozka>();
        //příkaz pro připojení k databázi
        string databaze = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\erikp\source\repos\Staty_Mesta\databaze.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection pripojeni;
        private void Form1_Load(object sender, EventArgs e)
        {
            //připojení k databázi
            pripojeni = new SqlConnection(databaze);
            vypis();
        }

        void vypis()
        {
            //vypsání do listu a listboxu
            lb_databaze.Items.Clear();
            string text_prikaz = "SELECT * FROM Zaklad"; //příkaz pro vypsání z databáze
            SqlCommand prikaz = new SqlCommand(text_prikaz, pripojeni);
            pripojeni.Open();
            SqlDataReader zaznamy = prikaz.ExecuteReader(); //provede příkaz
            while (zaznamy.Read())
            {
                polozky.Add(new Polozka(Convert.ToInt32(zaznamy["Id"]),zaznamy["stat"].ToString(), zaznamy["mesto"].ToString(), Convert.ToBoolean(zaznamy["hl_mesto"]), Convert.ToInt32(zaznamy["poc_obyv"]), Convert.ToInt32(zaznamy["rozloha"]), Convert.ToInt16(zaznamy["id_zrizeni"]), Convert.ToInt16(zaznamy["id_mena"]), zaznamy["hlava_statu"].ToString()));
                lb_databaze.Items.Add(polozky[polozky.Count - 1].Stat + " | " + polozky[polozky.Count - 1].Mesto);
                //zapsání dat z databáze do listu a následné vypsání z listu do listboxu v daném formátu 
            }
            pripojeni.Close();
        }

        private void bt_pridat_Click(object sender, EventArgs e)
        {
            //přidá novou položky dle vyplněných dat
            polozky.Add(new Polozka(0,tb_stat.Text, tb_mesto.Text, Convert.ToBoolean(cb_hlavni.Checked), int.Parse(tb_obyvatele.Text), int.Parse(tb_rozloha.Text), cb_zrizeni.SelectedIndex + 1, cb_mena.SelectedIndex + 1, tb_hlava.Text));
            string vlozit = $"INSERT INTO Zaklad(stat, mesto, hl_mesto, poc_obyv, rozloha, id_zrizeni, id_mena, hlava_statu) VALUES ('{tb_stat.Text}', '{tb_mesto.Text}', '{Convert.ToInt16(cb_hlavni.Checked)}', '{int.Parse(tb_obyvatele.Text)}', '{int.Parse(tb_rozloha.Text)}', '{cb_zrizeni.SelectedIndex + 1}', '{cb_mena.SelectedIndex + 1}', '{tb_hlava.Text}')";
            //příkaz na přidání položek do databáze
            pripojeni.Open();
            SqlCommand prikaz = new SqlCommand(vlozit, pripojeni);
            prikaz.ExecuteNonQuery(); //porvedení příkazu
            pripojeni.Close();
            vypis();
        }

        private void bt_editovat_Click(object sender, EventArgs e)
        {
            //edituje vybranou položky dle vyplněných dat
            for (int i=0; i<=lb_databaze.SelectedIndex; i++)
            {
                if (polozky[i].Stat + " | " + polozky[i].Mesto == lb_databaze.SelectedItem.ToString())
                {
                    //začátek zápisu do listu
                    polozky[i].Stat = tb_stat.Text;
                    polozky[i].Mesto = tb_mesto.Text;
                    polozky[i].Hlavni = Convert.ToBoolean(cb_hlavni.Checked);
                    polozky[i].Obyvatele = Convert.ToInt32(tb_obyvatele.Text);
                    polozky[i].Rozloha = Convert.ToInt32(tb_rozloha.Text);
                    polozky[i].Zrizeni = Convert.ToInt16(cb_zrizeni.SelectedIndex);
                    polozky[i].Mena = Convert.ToInt16(cb_mena.SelectedIndex);
                    polozky[i].Hlava = tb_hlava.Text;
                    //zápis do databáze
                    string edit = $"UPDATE Zaklad SET stat='{tb_stat.Text}', mesto='{tb_mesto.Text}', hl_mesto='{Convert.ToInt16(cb_hlavni.Checked)}', poc_obyv='{int.Parse(tb_obyvatele.Text)}', rozloha='{int.Parse(tb_rozloha.Text)}', id_zrizeni='{cb_zrizeni.SelectedIndex + 1}', id_mena='{cb_mena.SelectedIndex + 1}', hlava_statu='{tb_hlava.Text}' WHERE id='{polozky[i].ID}'";
                    //příkaz na přesný řádek v databázi pomocí "WHERE id='{polozky[i].ID}"
                    pripojeni.Open();
                    SqlCommand prikaz = new SqlCommand(edit, pripojeni);
                    prikaz.ExecuteNonQuery(); //provedení příkazu
                    pripojeni.Close();
                    vypis(); //opět načte do listboxu
                }     
            } 
        }

        private void bt_smazat_Click(object sender, EventArgs e)
        {
            //smaže vybranou položku
            for (int i = 0; i <= lb_databaze.SelectedIndex; i++)
            {
                if (polozky[i].Stat + " | " + polozky[i].Mesto == lb_databaze.SelectedItem.ToString())
                {
                    string smazat = $"DELETE FROM Zaklad WHERE id='{polozky[i].ID}'"; //příkaz na smazání požadovaného zápisu
                    polozky.Clear(); //vymaže list
                    pripojeni.Open();
                    SqlCommand prikaz = new SqlCommand(smazat, pripojeni);
                    prikaz.ExecuteNonQuery(); //provedení příkazu
                    pripojeni.Close();
                    vypis(); //opět načte do listu a listboxu
                }
            }
        }

        private void zmena(object sender, EventArgs e)
        {
            //uvolnění tlačítek pomocí základního ošetření
            if (tb_stat.Text.Length >= 3 && tb_mesto.Text.Length >= 3 && tb_obyvatele.Text.Length >= 1 && tb_rozloha.Text.Length >= 1 && cb_zrizeni.Text != "" && cb_mena.Text != "" && tb_hlava.Text.Length >= 3)
            {
                bt_pridat.Enabled = true;
                bt_editovat.Enabled = true;
            }
            else
            {
                bt_pridat.Enabled = false;
                bt_editovat.Enabled = false;
            }
        }

        private void lb_databaze_SelectedIndexChanged(object sender, EventArgs e)
        {
            //uvolnění tlačítka smazat
            if(lb_databaze.Text!="")
            {
                bt_smazat.Enabled = true;
            }
            else
            {
                bt_smazat.Enabled = false;
            }
            //přepínání vybrané položky s ošetřením na kliknutí mimo nějakou z položek
            try
            {
                tb_stat.Text = polozky[lb_databaze.SelectedIndex].Stat;
                tb_mesto.Text = polozky[lb_databaze.SelectedIndex].Mesto;
                if (polozky[lb_databaze.SelectedIndex].Hlavni == true)
                    cb_hlavni.Checked = true;
                else
                    cb_hlavni.Checked = false;
                tb_obyvatele.Text = polozky[lb_databaze.SelectedIndex].Obyvatele.ToString();
                tb_rozloha.Text = polozky[lb_databaze.SelectedIndex].Rozloha.ToString();
                cb_zrizeni.SelectedIndex = (polozky[lb_databaze.SelectedIndex].Zrizeni) - 1;
                cb_mena.SelectedIndex = (polozky[lb_databaze.SelectedIndex].Mena) - 1;
                tb_hlava.Text = polozky[lb_databaze.SelectedIndex].Hlava;
            }
            catch
            {
            }
        }

        private void bt_filtr_Click(object sender, EventArgs e)
        {
            //filtrování položek
            lb_filtrace.Items.Clear();
            int rozloha;
            if (tb_filtr_rozloha.Text == "") //ošetření vstupu NULL
                rozloha = 0;
            else
                rozloha = Convert.ToInt32(tb_filtr_rozloha.Text);
            for (int i=0;i<polozky.Count;i++)
            {
                if (moznost_hlavni.Checked) //vypsání podle hlavního města
                {
                    if (polozky[i].Hlavni == cb_filtr_hlavni.Checked)
                    {
                        lb_filtrace.Items.Add(polozky[i].Stat + " | " + polozky[i].Mesto);
                    } 
                }
                else if (moznost_rozloha.Checked) //vypsání podle rozlohy (větší než)
                {
                    if(polozky[i].Rozloha>=rozloha)
                    {
                        lb_filtrace.Items.Add(polozky[i].Stat + " | " + polozky[i].Mesto);
                    }
                }
                else if (moznost_zrizeni.Checked) //vypsání podle státního zřízení
                {
                    if (polozky[i].Zrizeni == cb_filtr_zrizeni.SelectedIndex+1)
                    {
                        lb_filtrace.Items.Add(polozky[i].Stat + " | " + polozky[i].Mesto);
                    }
                }
                else if(moznost_mena.Checked) //vypsání podle měny
                {
                    if(polozky[i].Mena==cb_filtr_mena.SelectedIndex+1)
                    {
                        lb_filtrace.Items.Add(polozky[i].Stat + " | " + polozky[i].Mesto);
                    }
                }
            }
        }

        private void bt_filtr_vymazat_Click(object sender, EventArgs e)
        {
            //vymazání filtrů
            cb_filtr_hlavni.Checked = false;
            tb_filtr_rozloha.Text = "";
            cb_filtr_zrizeni.Text = "";
            cb_filtr_mena.Text = "";
        }

        private void lb_filtrace_SelectedIndexChanged(object sender, EventArgs e)
        {
            //obstarává správné přepínání mezi listboxy
            lb_databaze.SelectedItem = lb_filtrace.SelectedItem.ToString();
        }

        private void moznosti(object sender, EventArgs e)
        {
            //práce s radiobuttony a povolení položek
            if (moznost_hlavni.Checked)
                cb_filtr_hlavni.Enabled = true;
            else
                cb_filtr_hlavni.Enabled = false;

            if (moznost_rozloha.Checked)
                tb_filtr_rozloha.Enabled = true;
            else
                tb_filtr_rozloha.Enabled = false;

            if (moznost_zrizeni.Checked)
                cb_filtr_zrizeni.Enabled = true;
            else
                cb_filtr_zrizeni.Enabled = false;

            if (moznost_mena.Checked)
                cb_filtr_mena.Enabled = true;
            else
                cb_filtr_mena.Enabled = false;
            //neumožňuje filtrovat bez filtru
            if (moznost_hlavni.Checked || moznost_rozloha.Checked || moznost_zrizeni.Checked || moznost_mena.Checked)
                bt_filtr.Enabled = true;
            else
                bt_filtr.Enabled = false;
        }
        //deklarace proměnných pro práci se zápisem
        string hlavni;
        string zrizeni;
        string mena;
        int j;
        private void bt_ulozit_Click(object sender, EventArgs e)
        {
            //zapsání do souboru
            StreamWriter soubor = new StreamWriter(tb_soubor.Text + ".csv"); //název souboru
            soubor.WriteLine("stat;mesto;hlavni_mesto;pocet_obyvatel;rozloha;zrizeni;mena;hlava_statu"); //hlavička
            string zapis;
            for(j=0; j<polozky.Count;j++)
            {
                pomoc(); //vyvolá práci s proměnnými pro každý záznam
                zapis = polozky[j].Stat + ";" + polozky[j].Mesto + ";" + hlavni + ";" + polozky[j].Obyvatele.ToString() + ";" + polozky[j].Rozloha.ToString() + ";" + zrizeni + ";" + mena + ";"+polozky[j].Hlava;
                soubor.WriteLine(zapis); //zapíše všechny položky do souboru
            }
            soubor.Close();
        }
        void pomoc()
        {
            //bool hlavní město přepíše na formát ano/ne
            if (polozky[j].Hlavni)
                hlavni = "ano";
            else
                hlavni = "ne";
            //zvolí potřebné zřízení
            switch (polozky[j].Zrizeni.ToString())
            {
                case "1":
                    zrizeni = "Konstituční monarchie";
                    break;
                case "2":
                    zrizeni = "Poloprezidentská republika";
                    break;
                case "3":
                    zrizeni = "Federativní parlamentní republika";
                    break;
                case "4":
                    zrizeni = "Konstituční monarchie";
                    break;
                case "5":
                    zrizeni = "Konfederativní republika";
                    break;
                case "6":
                    zrizeni = "Parlamentní republika";
                    break;
                case "7":
                    zrizeni = "Knížectví";
                    break;
            }
            //zvolí potřebnou měnu
            switch (polozky[j].Mena.ToString())
            {
                case "1":
                    mena = "Švédská koruna";
                    break;
                case "2":
                    mena = "Ukrajinská hřivna";
                    break;
                case "3":
                    mena = "Euro";
                    break;
                case "4":
                    mena = "Konvertibilné marka";
                    break;
                case "5":
                    mena = "Zlotý";
                    break;
            }
        }
    }
}
