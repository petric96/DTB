﻿namespace Staty_Mesta
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_databaze = new System.Windows.Forms.ListBox();
            this.lb_filtrace = new System.Windows.Forms.ListBox();
            this.tb_stat = new System.Windows.Forms.TextBox();
            this.tb_mesto = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_hlavni = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_obyvatele = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_rozloha = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_hlava = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cb_zrizeni = new System.Windows.Forms.ComboBox();
            this.cb_mena = new System.Windows.Forms.ComboBox();
            this.bt_pridat = new System.Windows.Forms.Button();
            this.bt_smazat = new System.Windows.Forms.Button();
            this.bt_editovat = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cb_filtr_hlavni = new System.Windows.Forms.CheckBox();
            this.tb_filtr_rozloha = new System.Windows.Forms.TextBox();
            this.cb_filtr_zrizeni = new System.Windows.Forms.ComboBox();
            this.cb_filtr_mena = new System.Windows.Forms.ComboBox();
            this.bt_filtr = new System.Windows.Forms.Button();
            this.bt_filtr_vymazat = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.moznost_hlavni = new System.Windows.Forms.RadioButton();
            this.moznost_rozloha = new System.Windows.Forms.RadioButton();
            this.moznost_zrizeni = new System.Windows.Forms.RadioButton();
            this.moznost_mena = new System.Windows.Forms.RadioButton();
            this.tb_soubor = new System.Windows.Forms.TextBox();
            this.bt_ulozit = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_databaze
            // 
            this.lb_databaze.FormattingEnabled = true;
            this.lb_databaze.Location = new System.Drawing.Point(12, 12);
            this.lb_databaze.Name = "lb_databaze";
            this.lb_databaze.Size = new System.Drawing.Size(205, 277);
            this.lb_databaze.TabIndex = 0;
            this.lb_databaze.SelectedIndexChanged += new System.EventHandler(this.lb_databaze_SelectedIndexChanged);
            // 
            // lb_filtrace
            // 
            this.lb_filtrace.FormattingEnabled = true;
            this.lb_filtrace.Location = new System.Drawing.Point(809, 12);
            this.lb_filtrace.Name = "lb_filtrace";
            this.lb_filtrace.Size = new System.Drawing.Size(205, 277);
            this.lb_filtrace.TabIndex = 1;
            this.lb_filtrace.SelectedIndexChanged += new System.EventHandler(this.lb_filtrace_SelectedIndexChanged);
            // 
            // tb_stat
            // 
            this.tb_stat.Location = new System.Drawing.Point(345, 12);
            this.tb_stat.Name = "tb_stat";
            this.tb_stat.Size = new System.Drawing.Size(199, 20);
            this.tb_stat.TabIndex = 2;
            this.tb_stat.Text = "test";
            this.tb_stat.TextChanged += new System.EventHandler(this.zmena);
            // 
            // tb_mesto
            // 
            this.tb_mesto.Location = new System.Drawing.Point(345, 38);
            this.tb_mesto.Name = "tb_mesto";
            this.tb_mesto.Size = new System.Drawing.Size(199, 20);
            this.tb_mesto.TabIndex = 3;
            this.tb_mesto.Text = "test";
            this.tb_mesto.TextChanged += new System.EventHandler(this.zmena);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(284, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Město:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(294, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Stát:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(254, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Hlavni město ?";
            // 
            // cb_hlavni
            // 
            this.cb_hlavni.AutoSize = true;
            this.cb_hlavni.Location = new System.Drawing.Point(345, 70);
            this.cb_hlavni.Name = "cb_hlavni";
            this.cb_hlavni.Size = new System.Drawing.Size(45, 17);
            this.cb_hlavni.TabIndex = 7;
            this.cb_hlavni.Text = "Ano";
            this.cb_hlavni.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(242, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Počet obyvatel:";
            // 
            // tb_obyvatele
            // 
            this.tb_obyvatele.Location = new System.Drawing.Point(345, 93);
            this.tb_obyvatele.Name = "tb_obyvatele";
            this.tb_obyvatele.Size = new System.Drawing.Size(199, 20);
            this.tb_obyvatele.TabIndex = 9;
            this.tb_obyvatele.Text = "123";
            this.tb_obyvatele.TextChanged += new System.EventHandler(this.zmena);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(274, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Rozloha:";
            // 
            // tb_rozloha
            // 
            this.tb_rozloha.Location = new System.Drawing.Point(345, 128);
            this.tb_rozloha.Name = "tb_rozloha";
            this.tb_rozloha.Size = new System.Drawing.Size(199, 20);
            this.tb_rozloha.TabIndex = 11;
            this.tb_rozloha.Text = "321";
            this.tb_rozloha.TextChanged += new System.EventHandler(this.zmena);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(223, 226);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Hlava státu:";
            // 
            // tb_hlava
            // 
            this.tb_hlava.Location = new System.Drawing.Point(291, 223);
            this.tb_hlava.Name = "tb_hlava";
            this.tb_hlava.Size = new System.Drawing.Size(253, 20);
            this.tb_hlava.TabIndex = 13;
            this.tb_hlava.Text = "Testiček";
            this.tb_hlava.TextChanged += new System.EventHandler(this.zmena);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(286, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Měna:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(247, 162);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Státní zřízení:";
            // 
            // cb_zrizeni
            // 
            this.cb_zrizeni.FormattingEnabled = true;
            this.cb_zrizeni.Items.AddRange(new object[] {
            "Konstituční monarchie",
            "Poloprezidentská republika",
            "Federativní parlamentní republika",
            "Konstituční monarchie",
            "Konfederativní republika",
            "Parlamentní republika",
            "Knížectví"});
            this.cb_zrizeni.Location = new System.Drawing.Point(345, 159);
            this.cb_zrizeni.Name = "cb_zrizeni";
            this.cb_zrizeni.Size = new System.Drawing.Size(199, 21);
            this.cb_zrizeni.TabIndex = 16;
            this.cb_zrizeni.SelectedIndexChanged += new System.EventHandler(this.zmena);
            // 
            // cb_mena
            // 
            this.cb_mena.FormattingEnabled = true;
            this.cb_mena.Items.AddRange(new object[] {
            "Švédská koruna",
            "Ukrajinská hřivna",
            "Euro",
            "Konvertibilné marky",
            "Zlotý"});
            this.cb_mena.Location = new System.Drawing.Point(345, 192);
            this.cb_mena.Name = "cb_mena";
            this.cb_mena.Size = new System.Drawing.Size(199, 21);
            this.cb_mena.TabIndex = 17;
            this.cb_mena.SelectedIndexChanged += new System.EventHandler(this.zmena);
            // 
            // bt_pridat
            // 
            this.bt_pridat.Enabled = false;
            this.bt_pridat.Location = new System.Drawing.Point(468, 251);
            this.bt_pridat.Name = "bt_pridat";
            this.bt_pridat.Size = new System.Drawing.Size(76, 38);
            this.bt_pridat.TabIndex = 18;
            this.bt_pridat.Text = "Přidat";
            this.bt_pridat.UseVisualStyleBackColor = true;
            this.bt_pridat.Click += new System.EventHandler(this.bt_pridat_Click);
            // 
            // bt_smazat
            // 
            this.bt_smazat.Enabled = false;
            this.bt_smazat.Location = new System.Drawing.Point(291, 251);
            this.bt_smazat.Name = "bt_smazat";
            this.bt_smazat.Size = new System.Drawing.Size(76, 38);
            this.bt_smazat.TabIndex = 19;
            this.bt_smazat.Text = "Smazat";
            this.bt_smazat.UseVisualStyleBackColor = true;
            this.bt_smazat.Click += new System.EventHandler(this.bt_smazat_Click);
            // 
            // bt_editovat
            // 
            this.bt_editovat.Enabled = false;
            this.bt_editovat.Location = new System.Drawing.Point(373, 251);
            this.bt_editovat.Name = "bt_editovat";
            this.bt_editovat.Size = new System.Drawing.Size(89, 38);
            this.bt_editovat.TabIndex = 20;
            this.bt_editovat.Text = "Editovat";
            this.bt_editovat.UseVisualStyleBackColor = true;
            this.bt_editovat.Click += new System.EventHandler(this.bt_editovat_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.Location = new System.Drawing.Point(588, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(210, 24);
            this.label13.TabIndex = 28;
            this.label13.Text = "FILTRACE POLOŽEK";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(550, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Hlavní město ?";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(550, 100);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Státní zřízení:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(589, 131);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Měna:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(503, 70);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(126, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "Rozloha (větší či rovna): ";
            // 
            // cb_filtr_hlavni
            // 
            this.cb_filtr_hlavni.AutoSize = true;
            this.cb_filtr_hlavni.Enabled = false;
            this.cb_filtr_hlavni.Location = new System.Drawing.Point(635, 40);
            this.cb_filtr_hlavni.Name = "cb_filtr_hlavni";
            this.cb_filtr_hlavni.Size = new System.Drawing.Size(45, 17);
            this.cb_filtr_hlavni.TabIndex = 25;
            this.cb_filtr_hlavni.Text = "Ano";
            this.cb_filtr_hlavni.UseVisualStyleBackColor = true;
            // 
            // tb_filtr_rozloha
            // 
            this.tb_filtr_rozloha.Enabled = false;
            this.tb_filtr_rozloha.Location = new System.Drawing.Point(632, 68);
            this.tb_filtr_rozloha.Name = "tb_filtr_rozloha";
            this.tb_filtr_rozloha.Size = new System.Drawing.Size(171, 20);
            this.tb_filtr_rozloha.TabIndex = 26;
            // 
            // cb_filtr_zrizeni
            // 
            this.cb_filtr_zrizeni.Enabled = false;
            this.cb_filtr_zrizeni.FormattingEnabled = true;
            this.cb_filtr_zrizeni.Items.AddRange(new object[] {
            "Konstituční monarchie",
            "Poloprezidentská republika",
            "Federativní parlamentní republika",
            "Konstituční monarchie",
            "Konfederativní republika",
            "Parlamentní republika",
            "Knížectví"});
            this.cb_filtr_zrizeni.Location = new System.Drawing.Point(632, 97);
            this.cb_filtr_zrizeni.Name = "cb_filtr_zrizeni";
            this.cb_filtr_zrizeni.Size = new System.Drawing.Size(171, 21);
            this.cb_filtr_zrizeni.TabIndex = 27;
            // 
            // cb_filtr_mena
            // 
            this.cb_filtr_mena.Enabled = false;
            this.cb_filtr_mena.FormattingEnabled = true;
            this.cb_filtr_mena.Items.AddRange(new object[] {
            "Švédská koruna",
            "Ukrajinská hřivna",
            "Euro",
            "Konvertibilné marky",
            "Zlotý"});
            this.cb_filtr_mena.Location = new System.Drawing.Point(632, 128);
            this.cb_filtr_mena.Name = "cb_filtr_mena";
            this.cb_filtr_mena.Size = new System.Drawing.Size(171, 21);
            this.cb_filtr_mena.TabIndex = 29;
            // 
            // bt_filtr
            // 
            this.bt_filtr.Enabled = false;
            this.bt_filtr.Location = new System.Drawing.Point(723, 155);
            this.bt_filtr.Name = "bt_filtr";
            this.bt_filtr.Size = new System.Drawing.Size(80, 23);
            this.bt_filtr.TabIndex = 30;
            this.bt_filtr.Text = "Filtrovat";
            this.bt_filtr.UseVisualStyleBackColor = true;
            this.bt_filtr.Click += new System.EventHandler(this.bt_filtr_Click);
            // 
            // bt_filtr_vymazat
            // 
            this.bt_filtr_vymazat.Location = new System.Drawing.Point(632, 155);
            this.bt_filtr_vymazat.Name = "bt_filtr_vymazat";
            this.bt_filtr_vymazat.Size = new System.Drawing.Size(80, 23);
            this.bt_filtr_vymazat.TabIndex = 31;
            this.bt_filtr_vymazat.Text = "Vymazat filtr";
            this.bt_filtr_vymazat.UseVisualStyleBackColor = true;
            this.bt_filtr_vymazat.Click += new System.EventHandler(this.bt_filtr_vymazat_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.Location = new System.Drawing.Point(631, 181);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(141, 20);
            this.label14.TabIndex = 36;
            this.label14.Text = "Možnosti filtrace";
            // 
            // moznost_hlavni
            // 
            this.moznost_hlavni.AutoSize = true;
            this.moznost_hlavni.Location = new System.Drawing.Point(617, 204);
            this.moznost_hlavni.Name = "moznost_hlavni";
            this.moznost_hlavni.Size = new System.Drawing.Size(88, 17);
            this.moznost_hlavni.TabIndex = 37;
            this.moznost_hlavni.TabStop = true;
            this.moznost_hlavni.Text = "Hlavní město";
            this.moznost_hlavni.UseVisualStyleBackColor = true;
            this.moznost_hlavni.CheckedChanged += new System.EventHandler(this.moznosti);
            // 
            // moznost_rozloha
            // 
            this.moznost_rozloha.AutoSize = true;
            this.moznost_rozloha.Location = new System.Drawing.Point(723, 204);
            this.moznost_rozloha.Name = "moznost_rozloha";
            this.moznost_rozloha.Size = new System.Drawing.Size(64, 17);
            this.moznost_rozloha.TabIndex = 38;
            this.moznost_rozloha.TabStop = true;
            this.moznost_rozloha.Text = "Rozloha";
            this.moznost_rozloha.UseVisualStyleBackColor = true;
            this.moznost_rozloha.CheckedChanged += new System.EventHandler(this.moznosti);
            // 
            // moznost_zrizeni
            // 
            this.moznost_zrizeni.AutoSize = true;
            this.moznost_zrizeni.Location = new System.Drawing.Point(617, 224);
            this.moznost_zrizeni.Name = "moznost_zrizeni";
            this.moznost_zrizeni.Size = new System.Drawing.Size(91, 17);
            this.moznost_zrizeni.TabIndex = 39;
            this.moznost_zrizeni.TabStop = true;
            this.moznost_zrizeni.Text = "Státní zřízení";
            this.moznost_zrizeni.UseVisualStyleBackColor = true;
            this.moznost_zrizeni.CheckedChanged += new System.EventHandler(this.moznosti);
            // 
            // moznost_mena
            // 
            this.moznost_mena.AutoSize = true;
            this.moznost_mena.Location = new System.Drawing.Point(723, 222);
            this.moznost_mena.Name = "moznost_mena";
            this.moznost_mena.Size = new System.Drawing.Size(52, 17);
            this.moznost_mena.TabIndex = 40;
            this.moznost_mena.TabStop = true;
            this.moznost_mena.Text = "Měna";
            this.moznost_mena.UseVisualStyleBackColor = true;
            this.moznost_mena.CheckedChanged += new System.EventHandler(this.moznosti);
            // 
            // tb_soubor
            // 
            this.tb_soubor.Location = new System.Drawing.Point(553, 269);
            this.tb_soubor.Name = "tb_soubor";
            this.tb_soubor.Size = new System.Drawing.Size(136, 20);
            this.tb_soubor.TabIndex = 41;
            this.tb_soubor.Text = "nazev_souboru";
            // 
            // bt_ulozit
            // 
            this.bt_ulozit.Location = new System.Drawing.Point(695, 269);
            this.bt_ulozit.Name = "bt_ulozit";
            this.bt_ulozit.Size = new System.Drawing.Size(105, 20);
            this.bt_ulozit.TabIndex = 42;
            this.bt_ulozit.Text = "Uložit do souboru";
            this.bt_ulozit.UseVisualStyleBackColor = true;
            this.bt_ulozit.Click += new System.EventHandler(this.bt_ulozit_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label15.Location = new System.Drawing.Point(550, 253);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(250, 13);
            this.label15.TabIndex = 43;
            this.label15.Text = "*Uloží všechny položky v databázi do CSV souboru";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1019, 295);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.bt_ulozit);
            this.Controls.Add(this.tb_soubor);
            this.Controls.Add(this.moznost_mena);
            this.Controls.Add(this.moznost_zrizeni);
            this.Controls.Add(this.moznost_rozloha);
            this.Controls.Add(this.moznost_hlavni);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.bt_filtr_vymazat);
            this.Controls.Add(this.bt_filtr);
            this.Controls.Add(this.cb_filtr_mena);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cb_filtr_zrizeni);
            this.Controls.Add(this.tb_filtr_rozloha);
            this.Controls.Add(this.cb_filtr_hlavni);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.bt_editovat);
            this.Controls.Add(this.bt_smazat);
            this.Controls.Add(this.bt_pridat);
            this.Controls.Add(this.cb_mena);
            this.Controls.Add(this.cb_zrizeni);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tb_hlava);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tb_rozloha);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_obyvatele);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cb_hlavni);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_mesto);
            this.Controls.Add(this.tb_stat);
            this.Controls.Add(this.lb_filtrace);
            this.Controls.Add(this.lb_databaze);
            this.Name = "Form1";
            this.Text = "Státy a města";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lb_databaze;
        private System.Windows.Forms.ListBox lb_filtrace;
        private System.Windows.Forms.TextBox tb_stat;
        private System.Windows.Forms.TextBox tb_mesto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cb_hlavni;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_obyvatele;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_rozloha;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_hlava;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cb_zrizeni;
        private System.Windows.Forms.ComboBox cb_mena;
        private System.Windows.Forms.Button bt_pridat;
        private System.Windows.Forms.Button bt_smazat;
        private System.Windows.Forms.Button bt_editovat;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox cb_filtr_hlavni;
        private System.Windows.Forms.TextBox tb_filtr_rozloha;
        private System.Windows.Forms.ComboBox cb_filtr_zrizeni;
        private System.Windows.Forms.ComboBox cb_filtr_mena;
        private System.Windows.Forms.Button bt_filtr;
        private System.Windows.Forms.Button bt_filtr_vymazat;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton moznost_hlavni;
        private System.Windows.Forms.RadioButton moznost_rozloha;
        private System.Windows.Forms.RadioButton moznost_zrizeni;
        private System.Windows.Forms.RadioButton moznost_mena;
        private System.Windows.Forms.TextBox tb_soubor;
        private System.Windows.Forms.Button bt_ulozit;
        private System.Windows.Forms.Label label15;
    }
}

